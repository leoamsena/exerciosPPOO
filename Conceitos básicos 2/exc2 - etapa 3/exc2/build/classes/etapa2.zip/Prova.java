
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aluno
 */
public class Prova {
    private Questao questao;
    private int tentativas;
    private static int qtdAceitaveis = 2;

    public Prova() {
        questao = new Questao();
        tentativas = 0;
    }
    public void aplicar(){
        if(tentativas != 0)
            System.out.println("Você ganhou mais uma chance! Digite outra resposta para a questão: ");
        else{
            System.out.println(questao.getEnunciado());
            System.out.print("Digite sua resposta: ");
        }
        Scanner sc = new Scanner(System.in);
        int resposta = sc.nextInt();
        tentativas++;
        if(questao.verificarResosta(resposta)){
            System.out.println("Muito bem, você acertou!");
            System.out.println("Você tentou "+tentativas+" vez(es) e acertou a questão.");
        }else{
            System.out.println("Infelizmente você errou!");
            if(tentativas>=qtdAceitaveis)
                System.out.println("Você tentou "+tentativas+" vez(es) e errou a questão.");
            else
                aplicar();
        }
    }
    
}
